import RemoteControl from "../components/RemoteControl";

export default function Rc() {
  return <RemoteControl />;
}
